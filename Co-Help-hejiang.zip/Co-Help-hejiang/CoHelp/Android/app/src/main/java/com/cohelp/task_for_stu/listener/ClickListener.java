package com.cohelp.task_for_stu.listener;

public interface ClickListener {
    void click();
}
