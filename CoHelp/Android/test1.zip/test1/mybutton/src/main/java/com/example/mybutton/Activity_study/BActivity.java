package com.example.mybutton.Activity_study;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.mybutton.R;

public class BActivity extends AppCompatActivity {

    private TextView mTvb;
    private Button mBtnb;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bactivity);

        mTvb = findViewById(R.id.tv_b);
        mBtnb = findViewById(R.id.bt_b);

        //获取A传过来的内容
        Bundle bundle = getIntent().getExtras();
        String name = bundle.getString("name");
        int age = bundle.getInt("age");

        mTvb.setText(name+" "+age);

        //返回给A的内容
        mBtnb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                Bundle bundle1 = new Bundle();
                bundle1.putString("message","我回来了");
                intent.putExtras(bundle1);
                setResult(AActivity.RESULT_OK,intent);
                finish();
            }
        });
    }
}