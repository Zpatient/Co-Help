package com.example.mybutton.Fragment;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.mybutton.R;

public class ContainerActivity extends AppCompatActivity {

    private AFragment aFragment;
    private Button mBtnChange;
    private BFragment bFragment;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_container);

        //创建对象
        aFragment = new AFragment();
        //把AFragment加载到Activity中，注意要调用commit这样可以避免一些错误
        getSupportFragmentManager().beginTransaction().add(R.id.fl_container,aFragment).commitAllowingStateLoss();

        mBtnChange = findViewById(R.id.bt_container);
        mBtnChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (bFragment == null) {
                    bFragment = new BFragment();
                    getSupportFragmentManager().beginTransaction().replace(R.id.fl_container,bFragment).commitAllowingStateLoss();
                }
            }
        });



    }
}