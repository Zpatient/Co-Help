package com.example.mybutton;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.mybutton.Activity_study.AActivity;
import com.example.mybutton.Fragment.ContainerActivity;
import com.example.mybutton.UI.UIActivity;

public class MainActivity extends AppCompatActivity {

    private Button myUI;
    private Button myAt;
    private Button myFg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        myUI = findViewById(R.id.bt_ui);
        myAt = findViewById(R.id.bt_activity);
        myFg = findViewById(R.id.bt_fragment);

        OnClick onClick = new OnClick();
        myUI.setOnClickListener(onClick);
        myAt.setOnClickListener(onClick);
        myFg.setOnClickListener(onClick);

    }


    class OnClick implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            Intent intent = null;
            switch (v.getId()){
                case R.id.bt_ui:
                    intent = new Intent(MainActivity.this, UIActivity.class);
                    break;
                case R.id.bt_activity:
                    intent = new Intent(MainActivity.this, AActivity.class);
                    break;
                case R.id.bt_fragment:
                    intent = new Intent(MainActivity.this, ContainerActivity.class);
                    break;
            }
            startActivity(intent);
        }
    }
}